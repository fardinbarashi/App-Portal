﻿<#
MonitorSystemServices

#>
# --------------------------------------------------
# Settings # 
 # Sql
  $SqlServer = ""
  $SqlInstance = ".\SQLEXPRESS" # Selected SQL ServerInstance
  $Database = "AppPortal" # Selected Database
  $Table = "MonitorSystemServices" # Selected Table
  $ExportTableAsCsvFilePath = "$PSScriptRoot\Dbo\AsCsv\MonitorSystemServices.csv" # FilePath to $Table

 # Mail
  $Mailto = "" # Mailadress to the group that owns the function
  $MailFrom = "" # Mailadress
  $SmtpServer = "" # Smtp

 # Transcript-Settings
  $TranScriptLogFileDate = (Get-Date -Format yyyy/MM/dd/HH.mm.ss)
  $TranScriptLogFile = "$PSScriptRoot\Logs\AppPortalMonitorSystemServices - $TranScriptLogFileDate.Txt" 

# - Start Transcript ------------------------------
 # Start Transcript
 $StartTranscript = Start-Transcript -Path $TranScriptLogFile -Force
 Get-Date -Format "yyyy/MM/dd HH:mm:ss" 
 Write-Host "Starting Transcript"
 Write-Host ""

# - Start Script  ------------------------------
 # Export $Table as Csv -
 $Step = "1"
 $StepTask = " - Export $Table as Csv "
  Try 
   { # Start Try, Export $Table as Csv
    Get-Date -Format "yyyy/MM/dd HH:mm:ss"
    Write-Output "$StepTask"
    Write-Output "Connect to SQL and Retrive Data... 0%"
    # Start Get Data from $Database $Table $SqlInstance
    $GetTable = Invoke-Sqlcmd -Query "SELECT * FROM [$Database].[dbo].[$Table]" -ServerInstance "$SqlInstance" -Verbose | 
    # Export Sql as data
    Export-Csv -Path "$ExportTableAsCsvFilePath" -NoTypeInformation -delimiter ',' -Encoding UTF8 -Force -Verbose
    If( (Test-Path $ExportTableAsCsvFilePath -PathType Leaf) ) 
     { # Start If
      Write-Output "Connect to SQL and Retrive Data... 100%"
      Write-Host ""
     } # End If      
   }  # End Try, Export $Table as Csv
  
  Catch 
   {  # Start Catch, Export $Table as Csv
    $MailSubject = "MonitorSystemServices Error - $Step"
    $MailBody = "Could not start $StepTask, See logfile and codesection $Step"

    Write-Warning $MailSubject
    Write-Warning $MailBody
  
    Write-Host $Error[0];
  
    Stop-Transcript
    $AttachmentLog = (get-childitem "$TranScriptLogFile").fullname
  
    Send-MailMessage -To $Mailto -from "$MailFrom" -Subject $MailSubject -Body $MailBody -SmtpServer $SmtpServer  -Attachments $AttachmentLog -Encoding ([System.Text.Encoding]::UTF8)     
   }  # End Catch, Export $Table as Csv

# ------------------------------- 
 # Import ExportTableAsCsvFilePath and create Objects
 $Step = "2"
 $StepTask = " - Import ExportTableAsCsvFilePath and create Objects"
  Try 
   { # Start Try,  Import ExportTableAsCsvFilePath and create Objects
    Get-Date -Format "yyyy/MM/dd HH:mm:ss"
    Write-Output "$StepTask... 0%"
    # Import Csv to String
    $Serverlist = Import-Csv $ExportTableAsCsvFilePath -Delimiter ',' -Encoding UTF8 | 
     ForEach { # Start Foreach
      New-Object PSObject -prop @{ # Start New-Object
       ID = $_.ID;
       Servername = $_.Servername;
       Ipadress = $_.Ipadress;
       System = $_.System;
       ServiceName = $_.ServiceName;
       DisplayName = $_.DisplayName;   
       Description = $_.Description;   
       Office = $_.Office;   
      } # End New-Object
     } # End Foreach
    Write-Output "$StepTask... 100%"       
    Write-Host "" 
   }  # End Try, Import ExportTableAsCsvFilePath and create Objects
  
  Catch 
   {  # Start Catch, Import ExportTableAsCsvFilePath and create Objects
    $MailSubject = "MonitorSystemServices Error - $Step"
    $MailBody = "Could not start $StepTask, See logfile and codesection $Step"

    Write-Warning $MailSubject
    Write-Warning $MailBody
  
    Write-Host $Error[0];
  
    Stop-Transcript
    $AttachmentLog = (get-childitem "$TranScriptLogFile").fullname
  
    Send-MailMessage -To $Mailto -from "$MailFrom" -Subject $MailSubject -Body $MailBody -SmtpServer $SmtpServer  -Attachments $AttachmentLog -Encoding ([System.Text.Encoding]::UTF8)     
   }  # End Catch, Import ExportTableAsCsvFilePath and create Objects

# -------------------------------
 # Check after stopped services
 $Step = "3"
 $StepTask = " - Check after stopped services" 
  Try 
   { # Start Try, Check after stopped services
    Get-Date -Format "yyyy/MM/dd HH:mm:ss"
    Write-Output "$StepTask... 0%"
    # Check services on servers
    Foreach ( $Server in $Serverlist )
    { # Start Foreach 
    Write-Host "Checking Server" $Server.Servername "- Service" $Server.ServiceName
      $GetStoppedServices = Invoke-Command -ScriptBlock { 
       Get-Service $args[0];} -ComputerName $Server.Servername -ArgumentList $Server.ServiceName.Split(",") |
       Select-Object PSComputerName, ServiceName, Status |
       Where-Object { $_.Status -Eq "Stopped" } | Start-Service
       Write-Host "" $GetStoppedServices.ServiceName $GetStoppedServices.Status
       Write-Host ""
    } # End Foreach
   Write-Output "$StepTask... 100%"   
   Write-Host "" 
   }  # End Try, Check after stopped services
  
  Catch 
   {  # Start Catch, Check after stopped services
    $MailSubject = "MonitorSystemServices Error - $Step"
    $MailBody = "Could not start $StepTask, See logfile and codesection $Step"

    Write-Warning $MailSubject
    Write-Warning $MailBody
  
    Write-Host $Error[0];
  
    Stop-Transcript
    $AttachmentLog = (get-childitem "$TranScriptLogFile").fullname
  
    Send-MailMessage -To $Mailto -from "$MailFrom" -Subject $MailSubject -Body $MailBody -SmtpServer $SmtpServer  -Attachments $AttachmentLog -Encoding ([System.Text.Encoding]::UTF8)     
   }  # End Catch, Check after stopped services


 # - End Transcript -
 $Step = "4"
 $StepTask = " - Stopping Transcript "
  Try 
   { # Start Try, End Transcript

    If ( $StartTranscript -Eq $Null ) 
    { # Start If
     #  String StartTranscript is empty
    } # End If
    Else 
    { # Start, Else
     Write-Host ""
     Get-Date -Format "yyyy/MM/dd HH:mm:ss" 
     Write-Host $StepTask
     Stop-Transcript
    } # End, Else
    Write-host ""    
   }  # End Try, End Transcript
  
  Catch 
   {  # Start Catch, End Transcript
    $MailSubject = "MonitorSystemServices Error - $Step"
    $MailBody = "Could not start $StepTask, See logfile and codesection $Step"

    Write-Warning $MailSubject
    Write-Warning $MailBody
  
    Write-Host $Error[0];
  
    Stop-Transcript
    $AttachmentLog = (get-childitem "$TranScriptLogFile").fullname
  
    Send-MailMessage -To $Mailto -from "$MailFrom" -Subject $MailSubject -Body $MailBody -SmtpServer $SmtpServer  -Attachments $AttachmentLog -Encoding ([System.Text.Encoding]::UTF8)     
   }  # End Catch, End Transcript



# - End Script  ------------------------------