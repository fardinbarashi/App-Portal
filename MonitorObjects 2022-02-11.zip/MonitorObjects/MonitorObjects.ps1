﻿<#
This Script exports $Table as a csv file.
When the csv export has been done is going to check after expiring objects in the csv file.
If the objects are going to be expired in about $DaysAlert, the team is going to be notified by mail.

#>

# Sql-Settings
$SqlServer = ""
$SqlInstance = ".\SQLEXPRESS" # Selected SQL ServerInstance
$Database = "AppPortal" # Selected Database
$Table = "MonitorObjects" # Selected Table
$ExportTableAsCsvFilePath = "$PSScriptRoot\Dbo\AsCsv\MonitorObjects.csv" # FilePath to $Table

# MailSettings
$Mailto = "" 
$MailFrom = "" 
$SmtpServer = "s"


# Other Settings
$DaysAlert = "30" # Days to alert
$ExpiredObjectsFile = "$PSScriptRoot\Files\ExpiredObjects\Expired Ojects In $DaysAlert Days.txt"

# Transcript-Settings
$TranScriptLogFileDate = (Get-Date -Format yyyy/MM/dd/HH.mm.ss)
$TranScriptLogFile = "$PSScriptRoot\Logs\AppPortalMonitorObjects - $TranScriptLogFileDate.Txt"
Start-Transcript -Path $TranScriptLogFile -Force
Write-Host ""

#  Remove Previous $ExpiredObjectsFile files
Try { # Start Try, Check if $ExpiredObjectsFile file exist
 Get-Date -Format "yyyy/MM/dd HH:mm:ss"
 Write-Output "Check if $ExpiredObjectsFile file exist... 0%"
 If( (Test-Path $ExpiredObjectsFile -PathType leaf) )
  { # Start If
   Write-Output "Removing $ExpiredObjectsFile file."
   Remove-Item -Path $ExpiredObjectsFile -Force
   Write-Output "Check if $ExpiredObjectsFile file exist... 100%"
 } # End If  
}  # End Try, Check if $ExpiredObjectsFile file exist 

Catch {  # Start Catch, Check if $ExpiredObjectsFile file exist 
  $MailSubject = "Error"
  $MailBody = "Could not Check if $ExpiredObjectsFile file exist"

  Write-Warning $MailSubject
  Write-Warning $MailBody
  
  Write-Host $Error[0];
  
  Stop-Transcript
  $AttachmentLog = (get-childitem "$TranScriptLogFile").fullname
  
Send-MailMessage -To $Mailto -from "$MailFrom" -Subject $MailSubject -Body $MailBody -SmtpServer $SmtpServer  -Attachments $AttachmentLog -Encoding ([System.Text.Encoding]::UTF8)    
}  # End Catch, Check if $ExpiredObjectsFile file exist 
#  Remove Previous $ExpiredObjectsFile files


# Export $Table as Csv
 Try { # Start Try, Export $Table as Csv
  Write-Output "Check if $ExpiredObjectsFile file exist... 100%"
  Write-Host ""
  Get-Date -Format "yyyy/MM/dd HH:mm:ss"
  Write-Output "Connect to SQL and Retrive Data... 0%"
  # Start Get Data from $Database $Table $SqlInstance
  $GetTable = Invoke-Sqlcmd -Query "SELECT * FROM [$Database].[dbo].[$Table]" -ServerInstance "$SqlInstance" -Verbose | 
  # Export Sql as data
  Export-Csv -Path "$ExportTableAsCsvFilePath" -NoTypeInformation -delimiter ',' -Encoding UTF8 -Force -Verbose
  If( (Test-Path $ExportTableAsCsvFilePath -PathType Leaf) ) 
  { # Start If
   Write-Output "Connect to SQL and Retrive Data... 100%"
  } # End If 
 } # End Try, Export $Table as Csv
 
 Catch { # Start Catch, Export $Table as Csv
  $MailSubject = "Error"
  $MailBody = "Could not Connect to SQL and Retrive Data"

  Write-Warning $MailSubject
  Write-Warning $MailBody
  
  Write-Host $Error[0];
  
  Stop-Transcript
  $AttachmentLog = (get-childitem "$TranScriptLogFile").fullname
  
Send-MailMessage -To $Mailto -from "$MailFrom" -Subject $MailSubject -Body $MailBody -SmtpServer $SmtpServer  -Attachments $AttachmentLog -Encoding ([System.Text.Encoding]::UTF8)     
 } # End Catch, Export $Table as Csv
# Export $Table as Csv

# Import $ExportTableAsCsvFilePath and create new-objects
 Try { # Start Try, Import $ExportTableAsCsvFilePath and create new-objects
 Write-Output "Connect to SQL and Retrive Data... 100%"
 Write-Host ""
 Get-Date -Format "yyyy/MM/dd HH:mm:ss"
 Write-Output "Import $ExportTableAsCsvFilePath and create new-objects... 0%"

 $ImportExportTableAsCsvFile = Import-Csv $ExportTableAsCsvFilePath -delimiter ',' -Encoding UTF8 | 
 Foreach { # Start Foreach
 New-Object PSObject -prop @{ # Start New-Object 
  ID = $_.ID;
  ServerName = $_.ServerName;
  ExpireDate = [DateTime]::Parse($_.ExpireDate);
  ObjectName = $_.ObjectName;
  Enviroment = $_.Enviroment;
  Template = $_.Template;
  Description = $_.Description;
  Office = $_.Office;
  System = $_.System;
  Message = $_.Message;
  } # End New-Object
 } # End Foreach 

} # End Try, Import $ExportTableAsCsvFilePath and create new-objects 

Catch { # Start Catch, Import $ExportTableAsCsvFilePath and create new-objects 
 $MailSubject = "Error"
 $MailBody = "Could not Import $ExportTableAsCsvFilePath and create new-objects "

 Write-Warning $MailSubject
 Write-Warning $MailBody
  
 Write-Host $Error[0];
  
 Stop-Transcript
 $AttachmentLog = (get-childitem "$TranScriptLogFile").fullname
  
 Send-MailMessage -To $Mailto -from "$MailFrom" -Subject $MailSubject -Body $MailBody -SmtpServer $SmtpServer -Encoding -Attachments $AttachmentLog ([System.Text.Encoding]::UTF8) 
} # Start Catch, Import $ExportTableAsCsvFilePath and create new-objects 
# Import $ExportTableAsCsvFilePath and create new-objects

# Check Import $ExportTableAsCsvFile for expiring objects
Try { # Start Try, Check $ImportExportTableAsCsvFile for expiring objects
 Write-Output "Import $ExportTableAsCsvFilePath and create new-objects... 100%"
 Write-Host ""
 Get-Date -Format "yyyy/MM/dd HH:mm:ss"
 Write-Output "Check $ExportTableAsCsvFilePath for expiring objects... 0%"

 $GetExpiredObjects = $ImportExportTableAsCsvFile | 
 Where-Object { $_.ExpireDate -Le (get-date).AddDays($DaysAlert) } 
   If ( $GetExpiredObjects -eq $Null ) 
    { # Start If,
    Write-Output "No expiring Objects"
    Write-Output "Check $ExportTableAsCsvFilePath for expiring objects... 100%"
    } # End If,
   Else
   { # Start Else, Expring Objects exist in $DaysAlert
    $ExpiredObjects = $ImportExportTableAsCsvFile | 
    Where-Object { $_.ExpireDate -Le (get-date).AddDays($DaysAlert) } | Out-File $ExpiredObjectsFile -Force
    Write-Output "Objects are going to expire"

    $Subject = " Cal-Reminder $DaysAlert days notification "
    $BodyContent = Get-Content -Path $ExpiredObjectsFile -Raw  
    $Body = "One or several objects is going to expire $DaysAlert days. See attached textfile for more information, When action has been taken dont forget to change ExpireDate value for the objects in the SQL-Table $Table. Here are the objects $BodyContent"
    $Attachment = (get-childitem "$ExpiredObjectsFile").fullname 
     
    Send-MailMessage -To $Mailto -from "$MailFrom" -Subject $Subject -Body $Body -Attachment $Attachment -SmtpServer $SmtpServer -Encoding ([System.Text.Encoding]::UTF8)
    Write-Output "Check $ExportTableAsCsvFilePath for expiring objects... 100%"
    Remove-Item -Path $ExpiredObjectsFile -Force 
   } # End Else, 
} # End Try, Import $ExportTableAsCsvFile for expiring objects

Catch{ # Start Catch, Check Import $ExportTableAsCsvFile for expiring objects
 $MailSubject = "Error"
 $MailBody = "Could not heck Import $ExportTableAsCsvFile for expiring objects"

 Write-Warning $MailSubject
 Write-Warning $MailBody
  
 Write-Host $Error[0];
  
 Stop-Transcript
 $AttachmentLog = (get-childitem "$TranScriptLogFile").fullname
  
 Send-MailMessage -To $Mailto -from "$MailFrom" -Subject $MailSubject -Body $MailBody -SmtpServer $SmtpServer -Encoding -Attachments $AttachmentLog ([System.Text.Encoding]::UTF8) 

} # End Catch, Check Import $ExportTableAsCsvFile for expiring objects
# Check Import $ExportTableAsCsvFile for expiring objects

 Stop-Transcript