﻿<#
 DESCRIPTION
 The Bot Checks $Table and matches event that will happen on the same day.
 The team gets notifiction on the channel on what will happen.
#>


# Sql-Settings
$SqlServer = ""
$SqlInstance = ".\SQLEXPRESS" # Selected SQL ServerInstance
$Database = "AppPortal" # Selected Database
$Table = "Bot" # Selected Table
$ExportTableAsCsvFilePath = "$PSScriptRoot\Dbo\AsCsv\Bot.csv" # FilePath to $Table

# MailSettings
$Mailto = "" 
$MailFrom = "" 
$SmtpServer = ""

# Get Todays Date
$GetTodaysDate = Get-Date -Format "yyyy-MM-dd"

# Other Settings
$TodaysEventCsvFile = "$PSScriptRoot\Files\TodaysEvent\TodaysEvent $GetTodaysDate.Csv" # File that contains Todays Event

# Transcript-Settings
$TranScriptLogFileDate = (Get-Date -Format yyyy/MM/dd/HH.mm.ss)
$TranScriptLogFile = "$PSScriptRoot\Logs\AppPortalBot - $TranScriptLogFileDate.Txt"
Start-Transcript -Path $TranScriptLogFile -Force
Write-Host ""


# Remove Old Files
Try 
 { # Start Try, FileCheck, Remove Old Files
  Write-Output "------------------------------------------------------------------------" 
  Get-Date -Format "yyyy/MM/dd HH:mm:ss"
  Write-Output "FileCheck, Remove Old Files... 0%"
  # FileCheck $ExportTableAsCsvFilePath
   $FileCheckExportTableAsCsvFilePath = Get-ChildItem -Path $ExportTableAsCsvFilePath -Recurse -Force | Test-Path -PathType Leaf
    If( $FileCheckExportTableAsCsvFilePath -Eq $Null )
     { # Start If, $FileCheckExportTableAsCsvFilePath -Eq $Null
        # $FileCheckExportTableAsCsvFilePath Is Empty
     } # End If, $FileCheckExportTableAsCsvFilePath -Eq $Null
    Else 
     { # Start Else, $FileCheckExportTableAsCsvFilePath -Eq $Null
      Write-host "Removing Previous $ExportTableAsCsvFilePath" -ForegroundColor Magenta
      Get-ChildItem -Path $ExportTableAsCsvFilePath -Force -Recurse | Remove-Item -Force
     } # End Else, $FileCheckExportTableAsCsvFilePath -Eq $Null
   
  # FileCheck $TodaysEventCsvFile 
   $FileCheckTodaysEventCsvFile = Get-ChildItem -Path $TodaysEventCsvFile -Recurse -Force | Test-Path -PathType Leaf
    If( $FileCheckTodaysEventCsvFile -Eq $Null )
     { # Start If, $FileCheckTodaysEventCsvFile -Eq $Null
       # $FileCheckTodaysEventCsvFile Is Empty
     } # End If, $FileCheckTodaysEventCsvFile -Eq $Null
    Else 
     { # Start Else, $FileCheckTodaysEventCsvFile -Eq $Null
      Write-host "Removing Previous $TodaysEventCsvFile" -ForegroundColor Magenta
      Get-ChildItem -Path $TodaysEventCsvFile -Force -Recurse | Remove-Item -Force
     } # Start Else, $FileCheckTodaysEventCsvFile -Eq $Null
 }  # End Try, FileCheck, Remove Old Files

Catch 
 { # Start Catch, FileCheck, Remove Old Files
  $MailSubject = "Error"
  $MailBody = "Could not start Process : FileCheck, Remove Old Files"
  Write-Warning $MailSubject
  Write-Warning $MailBody
  Write-Host $Error[0];
  
  Stop-Transcript
  $AttachmentLog = (get-childitem "$TranScriptLogFile").fullname
 
  Send-MailMessage -To $Mailto -from "$MailFrom" -Subject $MailSubject -Body $MailBody -SmtpServer $SmtpServer  -Attachments $AttachmentLog -Encoding ([System.Text.Encoding]::UTF8)
 } # End Catch, FileCheck, Remove Old Files
# Remove Old Files

Try 
 { # Start Try, Export $Table as Csv
  Write-Output "FileCheck, Remove Old Files... 100%" 
  Write-Output "------------------------------------------------------------------------"

  Get-Date -Format "yyyy/MM/dd HH:mm:ss"
  Write-Output "Connect to SQL and Retrive Data... 0%"
  # Start Get Data from $Database $Table $SqlInstance, Export Sql as csvfile
  $GetTable = Invoke-Sqlcmd -Query "SELECT * FROM [$Database].[dbo].[$Table]" -ServerInstance "$SqlInstance" -Verbose | 
  Export-Csv -Path "$ExportTableAsCsvFilePath" -NoTypeInformation -delimiter ',' -Encoding UTF8 -Force -Verbose
  If( (Test-Path $ExportTableAsCsvFilePath -PathType Leaf) ) 
  { # Start If, Test-Path $ExportTableAsCsvFilePath -PathType Leaf
   # Write-Output "Connect to SQL and Retrive Data... 100%"
  } # End If , Test-Path $ExportTableAsCsvFilePath -PathType Leaf
 } # End Try, Export $Table as Csv
 
Catch 
 { # Start Catch, Export $Table as Csv
  $MailSubject = "Error"
  $MailBody = "Could not start Process : Export $Table as Csv"
  Write-Warning $MailSubject
  Write-Warning $MailBody
  Write-Host $Error[0];
  
  Stop-Transcript
  $AttachmentLog = (get-childitem "$TranScriptLogFile").fullname
  
  Send-MailMessage -To $Mailto -from "$MailFrom" -Subject $MailSubject -Body $MailBody -SmtpServer $SmtpServer  -Attachments $AttachmentLog -Encoding ([System.Text.Encoding]::UTF8)
 } # End Catch, Export $Table as Csv
# Export $Table as Csv

 # Import $ExportTableAsCsvFilePath and create new-objects
 Try
 { # Start Try, Import $ExportTableAsCsvFilePath and create new-objects
  Write-Output "Connect to SQL and Retrive Data... 100%"
  Write-Output "------------------------------------------------------------------------"

  Get-Date -Format "yyyy/MM/dd HH:mm:ss"
  Write-Output "Import $ExportTableAsCsvFilePath and create new-objects... 0%"

  $ImportExportTableAsCsvFile = Import-Csv $ExportTableAsCsvFilePath -delimiter ',' -Encoding UTF8 | 
   Foreach { # Start Foreach
    New-Object PSObject -prop @{ # Start New-Object 
     ID = $_.ID;
     TodaysEvent = [DateTime]::Parse($_.TodaysEvent);
     TodaysEventDateStart = [DateTime]::Parse($_.TodaysEventDateStart);
     TodaysEventDateEnd = [DateTime]::Parse($_.TodaysEventDateEnd);
     System = $_.System;
     CurrentVersion = $_.CurrentVersion;
     UpgradeVersion = $_.UpgradeVersion;
     TaskDescription = $_.TaskDescription;
     SupplierTicket = $_.SupplierTicket;
     ChangeRequest = $_.ChangeRequest;
     SandBox = $_.SandBox;
     Production = $_.Production;
     Message = $_.Message;
    } # End New-Object
   } # End Foreach 
  } # End Try, Import $ExportTableAsCsvFilePath and create new-objects 

Catch 
 { # Start Catch, Import $ExportTableAsCsvFilePath and create new-objects 
  $MailSubject = "Error"
  $MailBody = "Could not start Process :Import $ExportTableAsCsvFilePath and create new-objects "
  Write-Warning $MailSubject
  Write-Warning $MailBody
  Write-Host $Error[0];
  
  Stop-Transcript
  $AttachmentLog = (get-childitem "$TranScriptLogFile").fullname
  
  Send-MailMessage -To $Mailto -from "$MailFrom" -Subject $MailSubject -Body $MailBody -SmtpServer $SmtpServer  -Attachments $AttachmentLog -Encoding ([System.Text.Encoding]::UTF8)
} # End Catch, Import $ExportTableAsCsvFilePath and create new-objects 
# Import $ExportTableAsCsvFilePath and create new-objects

# Check $ExportTableAsCsvFile for objects that have a matching TodaysEvent with todays date 
Try 
 { # Start Try, Check Import $ExportTableAsCsvFile for objects that have a matching TodaysEvent with todays date 
  Write-Output "Import $ExportTableAsCsvFilePath and create new-objects... 100%"
  Write-Output "------------------------------------------------------------------------"

  Get-Date -Format "yyyy/MM/dd HH:mm:ss"
  Write-Output "Check $ExportTableAsCsvFilePath for objects that have a matching TodaysEvent with todays date... 0%" 
 
  $GetTodaysEvent = $ImportExportTableAsCsvFile | 
   Where-Object { $_.TodaysEvent -Eq $GetTodaysDate } 
    If ( $GetTodaysEvent -eq $Null ) 
     { # Start If, $GetTodaysEvent -eq $Null 
      Write-Output "No objects that have a matching TodaysEvent with todays date"
      Write-Output "Check $ExportTableAsCsvFilePath for objects that have a matching TodaysEvent with todays date... 100%" 
     } # End If, $GetTodaysEvent -eq $Null 
    Else
     { # Start Else, Expring Objects exist in $DaysAlert
      $TodaysEvent = $ImportExportTableAsCsvFile | 
      Where-Object { $_.TodaysEvent -Eq $GetTodaysDate } | Export-Csv -Path "$TodaysEventCsvFile" -NoTypeInformation -delimiter ',' -Encoding UTF8 -Force -Verbose
     } # Start Else, Expring Objects exist in $DaysAlert
 } # End Try, Check Import $ExportTableAsCsvFile for objects that have a matching TodaysEvent with todays date 

Catch
 { # Start Catch, Check Import $ExportTableAsCsvFile for objects that have a matching TodaysEvent with todays date 
  $MailSubject = "Error"
  $MailBody = "Could not start Process : Check Import $ExportTableAsCsvFile for objects that have a matching TodaysEvent with todays date "
  Write-Warning $MailSubject
  Write-Warning $MailBody
  Write-Host $Error[0];
  
  Stop-Transcript
  $AttachmentLog = (get-childitem "$TranScriptLogFile").fullname
  
  Send-MailMessage -To $Mailto -from "$MailFrom" -Subject $MailSubject -Body $MailBody -SmtpServer $SmtpServer  -Attachments $AttachmentLog -Encoding ([System.Text.Encoding]::UTF8)  
} # End Catch, Check Import $ExportTableAsCsvFile for objects that have a matching TodaysEvent with todays date 
# Check $ExportTableAsCsvFile for objects that have a matching TodaysEvent with todays date 

# Create a Alert in teams about todays event
Try 
 { # Start Try, Create a Alert in teams about todays event
  Write-Output "Check $ExportTableAsCsvFilePath for objects that have a matching TodaysEvent with todays date... 100%"
  Write-Output "------------------------------------------------------------------------"

  Get-Date -Format "yyyy/MM/dd HH:mm:ss"
  Write-Output "Create a Alert in teams about todays event... 0%"
  
  $TodaysEventCsv = Import-Csv $TodaysEventCsvFile -delimiter ',' -Encoding UTF8 | 
   Foreach { # Start Foreach
    New-Object PSObject -prop @{ # Start New-Object 
    ID = $_.ID;
    TodaysEvent = [DateTime]::Parse($_.TodaysEvent);
    TodaysEventDateStart = [DateTime]::Parse($_.TodaysEventDateStart);
    TodaysEventDateEnd = [DateTime]::Parse($_.TodaysEventDateEnd);
    System = $_.System;
    CurrentVersion = $_.CurrentVersion;
    UpgradeVersion = $_.UpgradeVersion;
    TaskDescription = $_.TaskDescription;
    SupplierTicket = $_.SupplierTicket;
    ChangeRequest = $_.ChangeRequest;
    SandBox = $_.SandBox;
    Production = $_.Production;
    Message = $_.Message;
    }
   } # End Foreach 
 
   Foreach ( $Event In $TodaysEventCsv)
    { # Start Foreach ( $Event In $TodaysEventCsv)
     Write-Output "-------------------- TodaysEvent --------------------------------------------------"     
     Write-Host "ID : " $Event.ID 
     Write-Host "Task Description :" $Event.TaskDescription
     Write-Host "System : " $Event.System
     Write-Host "Start : "$Event.TodaysEventDateStart 
     Write-Host "Ends : "$Event.TodaysEventDateEnd
     Write-Host "Current Version : "$Event.CurrentVersion
     Write-Host "New Version : "$Event.UpgradeVersion
     Write-Host "Supplier Ticket : "$Event.SupplierTicket
     Write-Host "ChangeRequest : "$Event.ChangeRequest
     Write-Host "SandBox Or Production : "$Event.SandBox, $Event.Production
     Write-Host "Additional information :" $Event.Message
     Write-Output "-------------------- TodaysEvent --------------------------------------------------"     
    Write-Output "" 
   } # End Foreach ( $Event In $TodaysEventCsv)
    
    Write-Output "-------------------- Message to Team-Channel ----------------------------------------"  
    $BotMessage = "$($Event.Message) $($Event.TodaysEventDateStart) - $($Event.TodaysEventDateEnd)"
    Write-Output  $BotMessage 
    Write-Output "-------------------- Message to Team-Channel ----------------------------------------"  
    
    # Create Team Post
    $JSONBody = [PSCustomObject][Ordered]@{ # Start $JSONBody 
     "@type"      = "MessageCard"
     "@context"   = "http://schema.org/extensions"
     "summary"    = ""
     "themeColor" = ''
     "title"      = ""
     "text"       = "$BotMessage"
    } # End $JSONBody 
    # Convert $JSONBody ConvertTo-Json
    $TeamBotMessage = ConvertTo-Json $JSONBody -Depth 100

    $TeamBotMessageParameters = @{ # Start $TeamBotMessageParameters 
     "URI"         = ''
     "Method"      = 'POST'
     "Body"        = $TeamBotMessage
     "ContentType" = 'application/json; charset=utf-8'
    }
    # Send $TeamBotMessage To Teams
    Invoke-RestMethod @TeamBotMessageParameters -verbose 
    Stop-Transcript
} # End Try, Create a Alert in teams about todays event

Catch
 { # Start Catch, Create a Alert in teams about todays event
  $MailSubject = "Error"
  $MailBody = "Could not start Process : Create a Alert in teams about todays event"
  Write-Warning $MailSubject
  Write-Warning $MailBody
  Write-Host $Error[0];
  
  Stop-Transcript
  $AttachmentLog = (get-childitem "$TranScriptLogFile").fullname
  
  # Send-MailMessage -To $Mailto -from "$MailFrom" -Subject $MailSubject -Body $MailBody -SmtpServer $SmtpServer  -Attachments $AttachmentLog -Encoding ([System.Text.Encoding]::UTF8)  
 } # End Catch, Create a Alert in teams about todays event
# Check $ExportTableAsCsvFile for objects that have a matching TodaysEvent with todays date 


