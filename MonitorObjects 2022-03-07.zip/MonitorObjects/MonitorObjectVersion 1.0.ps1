﻿<#
This Script exports $Table as a csv file.
When the csv export has been done is going to check after expiring objects in the csv file.
If the objects are going to be expired in about $DaysAlert, the team is going to be notified by mail.

#>
# --------------------------------------------------
# Settings # 
 # Sql
  $SqlServer = ""
  $SqlInstance = ".\SQLEXPRESS" # Selected SQL ServerInstance
  $Database = "AppPortal" # Selected Database
  $Table = "MonitorObjects" # Selected Table
  $ExportTableAsCsvFilePath = "$PSScriptRoot\Dbo\AsCsv\MonitorObjects.csv" # FilePath to $Table

 # Mail
  $Mailto = "" # Mailadress to the group that owns the function
  $MailFrom = "" # Mailadress
  $SmtpServer = "" # Smtp

 # Other Settings
  $DaysAlert = "30" # Days to alert
  $ExpiredObjectsFile = "$PSScriptRoot\Files\ExpiredObjects\Expired Ojects In $DaysAlert Days.txt"

 # Transcript-Settings
  $TranScriptLogFileDate = (Get-Date -Format yyyy/MM/dd/HH.mm.ss)
  $TranScriptLogFile = "$PSScriptRoot\Logs\AppPortalMonitorObjects - $TranScriptLogFileDate.Txt" 

# - Start Transcript ------------------------------
 # Start Transcript
 $StartTranscript = Start-Transcript -Path $TranScriptLogFile -Force
 Get-Date -Format "yyyy/MM/dd HH:mm:ss" 
 Write-Host "Starting Transcript"
 Write-Host ""

# - Start Script  ------------------------------
 # - Remove Previous $ExpiredObjectsFile files -
 $Step = "Step 1"
 $StepTask = " - Check if Previous $ExpiredObjectsFile files exist"
  Try 
   { # Start Try, Check if $ExpiredObjectsFile file exist
    Get-Date -Format "yyyy/MM/dd HH:mm:ss"
    Write-Output "Check if $ExpiredObjectsFile file exist... 0%"
    If( (Test-Path $ExpiredObjectsFile -PathType leaf) )
     { # Start If
      Write-Output "Removing $ExpiredObjectsFile file."
      Remove-Item -Path $ExpiredObjectsFile -Force
      Write-Output "Check if $ExpiredObjectsFile file exist... 100%"
     } # End If 
    Else
     { # Start Else
      Write-Output "Check if $ExpiredObjectsFile file exist... 100%"
      Write-host 
     } # End Else 
   }  # End Try, Check if $ExpiredObjectsFile file exist 
  
  Catch 
   {  # Start Catch, Check if $ExpiredObjectsFile file exist 
    $MailSubject = "MonitorObjects Error - $Step"
    $MailBody = "Could not start $StepTask, See logfile and codesection $Step"

    Write-Warning $MailSubject
    Write-Warning $MailBody
  
    Write-Host $Error[0];
  
    Stop-Transcript
    $AttachmentLog = (get-childitem "$TranScriptLogFile").fullname
  
    Send-MailMessage -To $Mailto -from "$MailFrom" -Subject $MailSubject -Body $MailBody -SmtpServer $SmtpServer  -Attachments $AttachmentLog -Encoding ([System.Text.Encoding]::UTF8)     
   }  # End Catch, Check if $ExpiredObjectsFile file exist 

# -------------------------------

 # Export $Table as Csv -
 $Step = "2"
 $StepTask = " - Export $Table as Csv "
  Try 
   { # Start Try, Export $Table as Csv
    Get-Date -Format "yyyy/MM/dd HH:mm:ss"
    Write-Output "Export $Table as Csv... 0%"
    # Start Get Data from $Database $Table $SqlInstance
    $GetTable = Invoke-Sqlcmd -Query "SELECT * FROM [$Database].[dbo].[$Table]" -ServerInstance "$SqlInstance" -Verbose | 
    # Export Sql as data
    Export-Csv -Path "$ExportTableAsCsvFilePath" -NoTypeInformation -delimiter ',' -Encoding UTF8 -Force -Verbose
    If( (Test-Path $ExportTableAsCsvFilePath -PathType Leaf) ) 
     { # Start If
      Write-Output "Connect to SQL and Retrive Data... 100%"
      Write-Host ""
     } # End If      
   }  # End Try, Export $Table as Csv
  
  Catch 
   {  # Start Catch, Export $Table as Csv
    $MailSubject = "MonitorObjects Error - $Step"
    $MailBody = "Could not start $StepTask, See logfile and codesection $Step"

    Write-Warning $MailSubject
    Write-Warning $MailBody
  
    Write-Host $Error[0];
  
    Stop-Transcript
    $AttachmentLog = (get-childitem "$TranScriptLogFile").fullname
  
    Send-MailMessage -To $Mailto -from "$MailFrom" -Subject $MailSubject -Body $MailBody -SmtpServer $SmtpServer  -Attachments $AttachmentLog -Encoding ([System.Text.Encoding]::UTF8)     
   }  # End Catch, Export $Table as Csv

# -------------------------------

# - Import Sql-Table CsvFile and create new-objects -
 $Step = "3"
 $StepTask = " - Import Sql-Table CsvFile and create new-objects "
  Try 
   { # Start Try, Import Sql-Table CsvFile and create new-objects
    Get-Date -Format "yyyy/MM/dd HH:mm:ss"
    Write-Output "Import Sql-Table CsvFile and create new-objects... 0%"

    $ImportExportTableAsCsvFile = Import-Csv $ExportTableAsCsvFilePath -delimiter ',' -Encoding UTF8 | 
     Foreach { # Start Foreach
      New-Object PSObject -prop @{ # Start New-Object 
       ID = $_.ID;
       ServerName = $_.ServerName;
       ExpireDate = [DateTime]::Parse($_.ExpireDate);
       ObjectName = $_.ObjectName;
       Enviroment = $_.Enviroment;
       Template = $_.Template;
       Description = $_.Description;
       Office = $_.Office;
       System = $_.System;
       Message = $_.Message;
      } # End New-Object
     } # End Foreach 
    Write-Output "Import Sql-Table CsvFile and create new-objects... 100%"
    Write-host ""    
   }  # End Try, Import Sql-Table CsvFile and create new-objects
  
  Catch 
   {  # Start Catch, Import Sql-Table CsvFile and create new-objects
    $MailSubject = "MonitorObjects Error - $Step"
    $MailBody = "Could not start $StepTask, See logfile and codesection $Step"

    Write-Warning $MailSubject
    Write-Warning $MailBody
  
    Write-Host $Error[0];
  
    Stop-Transcript
    $AttachmentLog = (get-childitem "$TranScriptLogFile").fullname
  
    Send-MailMessage -To $Mailto -from "$MailFrom" -Subject $MailSubject -Body $MailBody -SmtpServer $SmtpServer  -Attachments $AttachmentLog -Encoding ([System.Text.Encoding]::UTF8)     
   }  # End Catch, Import Sql-Table CsvFile and create new-objects

# -------------------------------
 # Check for expiring objects -
 $Step = "4"
 $StepTask = " - Check for expiring objects "
  Try 
   { # Start Try, Check for expiring objects
    Get-Date -Format "yyyy/MM/dd HH:mm:ss"
    Write-Output "Check for expiring objects... 0%"

    $GetExpiredObjects = $ImportExportTableAsCsvFile |
    Where-Object { $_.ExpireDate -Le (get-date).AddDays($DaysAlert) } 
    If ( $GetExpiredObjects -eq $Null ) 
     { # Start If
      Write-Output "No expiring Objects"
      Write-Output "Check $ExportTableAsCsvFilePath for expiring objects... 100%"
     } # End If 

    Else
     { # Start Else
      $ExpiredObjects = $ImportExportTableAsCsvFile | 
      Where-Object { $_.ExpireDate -Le (get-date).AddDays($DaysAlert) } | Out-File $ExpiredObjectsFile -Force
      Write-Output "Objects are going to expire"

      $Subject = " Cal-Reminder $DaysAlert days notification "
      $BodyContent = Get-Content -Path $ExpiredObjectsFile -Raw  

      $Body = "One or several objects is going to expire $DaysAlert days. See attached textfile for more information, When action has been taken dont forget to change ExpireDate value for the objects in the SQL-Table $Table. Here are the objects $BodyContent"
      $Attachment = (get-childitem "$ExpiredObjectsFile").fullname  
      Send-MailMessage -To $Mailto -from "$MailFrom" -Subject $Subject -Body $Body -Attachment $Attachment -SmtpServer $SmtpServer -Encoding ([System.Text.Encoding]::UTF8)
     
      Write-Output "Check $ExportTableAsCsvFilePath for expiring objects... 100%"
      Remove-Item -Path $ExpiredObjectsFile -Force           
     } # End Else 
      Write-host ""    
   }  # End Try, Check for expiring objects
  
  Catch 
   {  # Start Catch, Check for expiring objects
    $MailSubject = "MonitorObjects Error - $Step"
    $MailBody = "Could not start $StepTask, See logfile and codesection $Step"

    Write-Warning $MailSubject
    Write-Warning $MailBody
  
    Write-Host $Error[0];
  
    Stop-Transcript
    $AttachmentLog = (get-childitem "$TranScriptLogFile").fullname
  
    Send-MailMessage -To $Mailto -from "$MailFrom" -Subject $MailSubject -Body $MailBody -SmtpServer $SmtpServer  -Attachments $AttachmentLog -Encoding ([System.Text.Encoding]::UTF8)     
   }  # End Catch, Check for expiring objects

# -------------------------------

 # - End Transcript -
 $Step = "5"
 $StepTask = " - End Transcript "
  Try 
   { # Start Try, End Transcript
    Get-Date -Format "yyyy/MM/dd HH:mm:ss"
    Write-Output "End Transcript... 0%"

    If ( $StartTranscript -Eq $Null ) 
    { # Start If
     #  String StartTranscript is empty
    } # End If
    Else 
    { # Start, Else
     Write-Host ""
     Get-Date -Format "yyyy/MM/dd HH:mm:ss" 
     Write-Host "Stopping Transcript"
     Stop-Transcript
    } # End, Else
    Write-host ""    
   }  # End Try, End Transcript
  
  Catch 
   {  # Start Catch, End Transcript
    $MailSubject = "MonitorObjects Error - $Step"
    $MailBody = "Could not start $StepTask, See logfile and codesection $Step"

    Write-Warning $MailSubject
    Write-Warning $MailBody
  
    Write-Host $Error[0];
  
    Stop-Transcript
    $AttachmentLog = (get-childitem "$TranScriptLogFile").fullname
  
    Send-MailMessage -To $Mailto -from "$MailFrom" -Subject $MailSubject -Body $MailBody -SmtpServer $SmtpServer  -Attachments $AttachmentLog -Encoding ([System.Text.Encoding]::UTF8)     
   }  # End Catch, End Transcript



# - End Script  ------------------------------